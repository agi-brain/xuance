ENVIRONMENT_IDS = ['FetchPickAndPlace-v1',
                   'FetchPush-v1',
                   'FetchReach-v1',
                   'FetchSlide-v1',
                   'HandManipulateBlock-v0',
                   'HandManipulateEgg-v0',
                   'HandManipulatePen-v0',
                   'HandReach-v0']
